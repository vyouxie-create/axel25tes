-- Jalankan di Supabase: SQL Editor
do $$ declare t text; begin
foreach t in array array['settings','packages','posts','products','rentals','orders'] loop
 execute format('create table if not exists public.%I(id text primary key, data jsonb not null, created_at timestamptz default now())',t);
 execute format('alter table public.%I enable row level security',t);
 execute format('drop policy if exists admin_all on public.%I',t);
 execute format('create policy admin_all on public.%I for all to authenticated using (true) with check (true)',t);
 if t<>'orders' then
  execute format('drop policy if exists pub_read on public.%I',t);
  execute format('create policy pub_read on public.%I for select to anon using (true)',t);
 end if;
end loop; end $$;
drop policy if exists anon_insert on public.orders;
create policy anon_insert on public.orders for insert to anon with check (true);
create or replace function public.get_order(oid text) returns jsonb language sql security definer set search_path=public as
$$ select data - 'proof' - 'wa' from orders where id=oid $$;
create or replace function public.recent_orders() returns jsonb language sql security definer set search_path=public as
$$ select coalesce(jsonb_agg(t.x),'[]'::jsonb) from (select jsonb_build_object('name',left(coalesce(data->>'name','?'),1)||'***','item',data->>'item','price',coalesce((data->>'price')::int,0),'type',data->>'type') x from orders where data->>'type'<>'rental' order by created_at desc limit 10) t $$;
grant execute on function public.get_order(text), public.recent_orders() to anon, authenticated;
