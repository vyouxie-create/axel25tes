AXEL25 + Supabase
1. supabase.com > New project. SQL Editor > tempel isi supabase-schema.sql > Run.
2. Authentication > Sign In / Providers: MATIKAN 'Allow new users to sign up'.
3. Authentication > Users > Add user: isi email + password admin (centang auto-confirm).
4. Project Settings > API: salin Project URL dan anon public key ke config.js.
5. Upload semua isi folder ke hosting (root domain). Rute: /joki /cek /rental /post /katalog /admin.
6. Buka /admin, login. Atur QR tiap paket (tab Joki), link saluran & WA (tab Konten), produk, rental.
Jangan pernah memasukkan service_role key ke config.js.
